export async function POST(req) {
    const API_KEY = process.env.GEMINI_API_KEY; // Lấy API Key từ Vercel Env
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`;

    try {
        const requestBody = await req.json();

        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody),
        });

        const result = await response.json();
        return new Response(JSON.stringify(result), { 
            headers: { "Content-Type": "application/json" },
            status: response.status,
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: "Lỗi khi gọi API Gemini" }), { 
            headers: { "Content-Type": "application/json" },
            status: 500,
        });
    }
}
